// File: shape_painter.dart

import 'package:flutter/material.dart';

class ShapePainter extends CustomPainter {
  final int shapeType;

  ShapePainter(this.shapeType);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blue
      ..style = PaintingStyle.fill;

    if (shapeType == 1) {
      // Vẽ hình tròn
      canvas.drawCircle(Offset(size.width / 2, size.height / 2), 50, paint);
    } else if (shapeType == 2) {
      // Vẽ hình vuông
      canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}